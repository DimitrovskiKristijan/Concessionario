-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Set 09, 2023 alle 14:19
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `concessionario`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `automobili`
--

CREATE TABLE `automobili` (
  `codice` int(11) NOT NULL,
  `citta` varchar(20) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `descrizione` varchar(50) NOT NULL,
  `costo` int(11) NOT NULL,
  `acquistato` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `automobili`
--

INSERT INTO `automobili` (`codice`, `citta`, `nome`, `descrizione`, `costo`, `acquistato`) VALUES
(1, 'Roma', 'Fiat 500', 'Rossa 75CV', 10000, 0),
(2, 'Napoli', 'Fiat Panda', 'Beige 86CV', 7000, 1),
(3, 'Bari', 'BMW X5', 'Nero 190CV', 100000, 0),
(4, 'Venezia', 'Ford Focus', 'Verde 115CV', 25000, 0),
(5, 'Milano', 'lamborghini', 'arancione 670CV', 250000, 0),
(6, 'Palermo', 'Renault Clio', 'Grigio 90CV', 12000, 0),
(7, 'Cagliari', 'Ferrari', 'Rosso 550CV', 300000, 0),
(8, 'Marseille', 'Ford', 'Focus ST', 40000, 0),
(9, 'Napoli', 'Ape 50', 'Verde 15CV', 500, 0);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `automobili`
--
ALTER TABLE `automobili`
  ADD PRIMARY KEY (`codice`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `automobili`
--
ALTER TABLE `automobili`
  MODIFY `codice` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
