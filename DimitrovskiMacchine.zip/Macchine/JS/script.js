var map, modal, testoModal;
urlBase = window.location.href;//recupera il tuo url

window.onload = async function(){
    await caricaMappa()
}

async function caricaMappa() {
    let busta = await fetch(urlBase + "server/index.php?acquistato=0", {
        method: "get",
    });
    //Leggo il contenuto della busta
    let datiDb = await busta.json();

    modal = document.getElementById("Modal");
    testoModal = document.querySelector("#interno main");

    let mappa = await fetch("https://nominatim.openstreetmap.org/search?format=json&country=Italy"); //
    let vet = await mappa.json(); 
    let coord = [parseFloat(vet[0].lon), parseFloat(vet[0].lat)];

    map = new ol.Map(
        {
            target:"mappa", //metto ID HTML
            layers:[
                new ol.layer.Tile({source:new ol.source.OSM()})
            ],
            view:new ol.View({
                center: ol.proj.fromLonLat(coord),//Cordinate scritte in float
                zoom:5
            })
    });

    let layer1 = aggiungiLayer(map, "img/marker2.png");

    for(let automobile of datiDb.auto){
        let promise = fetch("https://nominatim.openstreetmap.org/search?format=json&city="+automobile.citta);//indico dove inserire il marker sulla mappa
        promise.then(async function(mappa){
            let vet = await mappa.json(); 
            let coord = [parseFloat(vet[0].lon), parseFloat(vet[0].lat)];
            aggiungiMarker(layer1, automobile, coord[0], coord[1])
        });
    }
    //Gestione del click
    map.on("click", function (evento){
        map.forEachFeatureAtPixel(evento.pixel, function(marker){
            try {
                console.log(marker.dati);
            }
            catch(err) {
                alert("Errore nella visualizzazione")
            }
            testoModal.innerHTML = "Nome: " + marker.dati.nome + "<br>" + "Descrizione: " + marker.dati.descrizione
            + "<br>costo: " + marker.dati.costo + "<br>Città: " + marker.dati.citta
            + "<br><br><button  onclick='acquista("+ marker.dati.codice +")' id='acquistoVeic'>Acquista il veicolo</button>" ;
            modal.style.display = "flex";
        });
        
    });
}

function aggiungiMarker(layer, dati,  lon, lat){//dati sta per dati del marker
    let punto = new ol.geom.Point(ol.proj.fromLonLat([lon, lat]));
    let marker = new ol.Feature(punto);

    dati.lon = lon;
    dati.lat = lat;
    marker.dati = dati;    
    layer.getSource().addFeature(marker);//attacco il marker al layer
}

function aggiungiLayer(mappa, pathImg){
    let layer = new ol.layer.Vector({
        source:new ol.source.Vector(),
        style: new ol.style.Style({
            image: new ol.style.Icon({
                anchor:[0.5, 1],
                src:pathImg
            })
        }) 
    });
    mappa.addLayer(layer);
    return layer;
}

function chiudiModal(){
    modal.style.display = "none";
}

async function aggVeicolo() {
    let obj = {}
    obj["citta"] = document.getElementById("txtCit").value
    obj["nome"] = document.getElementById("txtN").value
    obj["descrizione"] = document.getElementById("txtDesc").value
    obj["costo"] = document.getElementById("txtC").value

    let response = await fetch("server/aggiunta.php", {
        method: "post",
        enctype: "multipart/form-data",
        body: JSON.stringify(obj)
    });
    let result = await response.text()
    alert(result)
    location.reload()
}

async function acquista(codice){
    let response = await fetch("server/acquisto.php?codice="+codice);
    let result = await response.text()
    alert(result)
    location.reload()
}