<?php
    $jObj = null;

    //Collegamento al DB  
    $indirizzoServerDBMS = "localhost";
    $nomeDb = "concessionario";
    $conn = mysqli_connect($indirizzoServerDBMS, "root", "", $nomeDb);
    if($conn->connect_errno>0){
        $jObj = preparaRisp(-1, "Connessione rifiutata");
        echo json_encode($jobj);
        exit;
    }else{
        $jObj = preparaRisp(0, "Connessione ok");
        $cod = $_GET["codice"];
        $query = "UPDATE automobili SET acquistato = 1 WHERE codice = ".$cod;
        $result = $conn->query($query);
        echo 'Veicolo acquistato con successo';
    }

    function preparaRisp($cod, $desc, $jObj = null){
        if(is_null($jObj)){
            $jObj = new stdClass();
        }
        $jObj->cod = $cod;
        $jObj->desc = $desc;
        return $jObj;
    }

    