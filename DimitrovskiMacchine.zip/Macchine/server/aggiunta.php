<?php
    $jObj = null;

    //Collegamento al DB
    $indirizzoServerDBMS = "localhost";
    $nomeDb = "concessionario";
    $conn = mysqli_connect($indirizzoServerDBMS, "root", "", $nomeDb);
    if($conn->connect_errno>0){
        $jObj = preparaRisp(-1, "Connessione rifiutata");
        echo json_encode($jObj);
        exit;
    }else{
        $jObj = preparaRisp(0, "Connessione ok");
        $dati = json_decode(file_get_contents('php://input'));//Vado a prendere i dati  e li decodifico
        $query = "INSERT INTO automobili (codice, citta, nome, descrizione, costo, acquistato) 
                    VALUES (NULL,
                            '".$dati->citta."',
                            '".$dati->nome."',
                            '".$dati->descrizione."',
                            ".$dati->costo.",'0');";

        $result = $conn->query($query);
        $jObj = preparaRisp(0, "Il veicolo è stato inserito correttamente");
        $risposta = json_encode($jObj);
        echo $risposta;
    }

    function preparaRisp($cod, $desc, $jObj = null){
        if(is_null($jObj)){
            $jObj = new stdClass();
        }
        $jObj->cod = $cod;
        $jObj->desc = $desc;
        return $jObj;
    }

    
