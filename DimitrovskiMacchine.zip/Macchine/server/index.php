<?php
    $jObj = null;

    //CollegaMENTO AL DB   
    $indirizzoServerDBMS = "localhost";
    $nomeDb = "concessionario";
    $conn = mysqli_connect($indirizzoServerDBMS, "root", "", $nomeDb);
    if($conn->connect_errno>0){
        $jObj = preparaRisp(-1, "Connessione rifiutata");
    }else{
        $jObj = preparaRisp(0, "Connessione ok");
    }

    //3 Verificare se non esiste già il record
    $query = "SELECT *   
        FROM automobili WHERE acquistato = ".$_GET["acquistato"]
        ;
    $risposta = $conn->query($query);
    if($risposta){
        $automobili = array();
        $cont =0;
        if($risposta->num_rows > 0){
            while($V = $risposta->fetch_assoc()){
        
                $automobili[$cont] = new stdClass();
                $automobili[$cont]->codice =  $V["codice"];
                $automobili[$cont]->citta =  $V["citta"];
                $automobili[$cont]->nome =  $V["nome"];
                $automobili[$cont]->descrizione =  $V["descrizione"];
                $automobili[$cont]->costo =  $V["costo"];
                $cont++;

            }
            $jObj->auto = $automobili;
        }else{
            $jObj = preparaRisp(-1, "Nessun automobile trovata");
        }
    }else{
        //Quando ci sono errori
        $jObj = preparaRisp(-1, "Errore nella query: ".$conn->error);
    }

    //Rispondo al javascript (al client)
    echo json_encode($jObj);
function preparaRisp($cod, $desc, $jObj = null){
        if(is_null($jObj)){
            $jObj = new stdClass();
        }
        $jObj->cod = $cod;
        $jObj->desc = $desc;
        return $jObj;
    }

    

